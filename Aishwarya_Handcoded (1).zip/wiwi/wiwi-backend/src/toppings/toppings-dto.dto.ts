import { Decimal128 } from "mongoose";
export class ToppingsDto {

    name: string;
    
    price: number;
     top_img:string;
}