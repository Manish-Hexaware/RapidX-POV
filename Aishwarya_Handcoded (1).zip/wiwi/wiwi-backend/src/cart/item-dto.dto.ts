export class ItemDTO {
    item: string;
    name: string;
    quantity: number;
    price: number;
  }