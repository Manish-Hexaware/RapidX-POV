// import { Decimal128 } from "mongoose";
// export class MenuDto {

//     item: string;
//     store_id: number[];
//     base_price: number;
//     toppings: string[];
//     item_description: string;

//  }