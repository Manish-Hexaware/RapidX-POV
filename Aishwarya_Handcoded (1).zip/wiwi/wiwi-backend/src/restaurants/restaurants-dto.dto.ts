// export declare class RestaurantDto {

//     name: string;

// }